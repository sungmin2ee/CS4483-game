Group 23: Lania: Demon Invasion (Survival Game) - Delivery 2

Controls
Move: Arrow keys

Attack: Spacebar

How to Play
Use arrow keys to navigate the game area

Press spacebar to attack enemies

Survive for 30 seconds to complete each round.

Level up to upgrade your weapon and increase your chances of survival

There is a ending scene when player dies or survive until the end.